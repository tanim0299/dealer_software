@extends('driver.layouts.master')

@section('body')
<nav class="navbar navbar-dark bg-primary mb-4">
    <div class="container-fluid">
        <button class="btn btn-light" onclick="history.back()">← Back</button>
        <span class="navbar-brand mx-auto">Expense List</span>
    </div>
</nav>

<div class="container mx-auto p-2">

    <!-- Filters -->



</div>
@endsection
