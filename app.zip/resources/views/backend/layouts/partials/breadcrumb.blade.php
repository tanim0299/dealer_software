<div>
    <h3 class="fw-bold mb-3">{{$page_title ?? 'No Title'}}</h3>
</div>