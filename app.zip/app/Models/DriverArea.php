<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DriverArea extends Model
{
    protected $guarded = [];
}
